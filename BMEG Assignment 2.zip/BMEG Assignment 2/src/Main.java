import java.util.*;
public class Main {
    /**
     * @author lucaszafran
     */
        static Scanner s = new Scanner(System.in);

        public static void main(String[] args) {

            int namechange[] = {0, 1, 2, 3, 4};
            int bar[] = new int[100];

            for (int i = 1; i <= 99; i++) {
                bar[i] = i;

            }
 /*for(int j=0; j < bar.length; j++){
   System.out.println(bar[j]);
 } */

            System.out.println("The number of even numbers in namechange is: ");
            System.out.println(countEvenNum(namechange, 5));

            System.out.println("The number of even numbers in bar is: ");
            System.out.println(countEvenNum(bar, 100));

        }

        public static int countEvenNum(int[] arr, int size) {
            int count = 0;

            for (int i = 0; i < arr.length; i++) {
                if (arr[i] % 2 == 0) {
                    count++;
                }
            }
            return count;
        }

    }

